#if defined (_MSC_VER)
int access(const char *path, int amode);
char *getcwd(char *_buf, size_t _size );
int mkdir(const char *path);
int chdir (const char *__path );
#endif
