//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Script1.rc
//
#define IDD_MAIN                        101
#define IDI_ICON1                       102
#define IDC_ABOUT                       1000
#define IDC_WADLIST                     1001
#define IDC_PLAYLIST                    1002
#define IDC_PLAY                        1003
#define IDC_ADD                         1004
#define IDC_REMOVE                      1005
#define IDC_OPEN                        1006
#define IDC_TITLE                       1007
#define IDC_ARTIST                      1008

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1009
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
