#!/bin/sh

./pngtest ${srcdir}/pngtest.png
